package test;


public class LFU {

}
