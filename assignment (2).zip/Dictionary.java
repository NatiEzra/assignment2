package test;


public class Dictionary {

}
